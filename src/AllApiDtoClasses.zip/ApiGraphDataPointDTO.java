package ca.cmpt213.as5courseplanner.controllers.datatransferobjects;

public class ApiGraphDataPointDTO {
    public long semesterCode;
    public long totalCoursesTaken;
}
