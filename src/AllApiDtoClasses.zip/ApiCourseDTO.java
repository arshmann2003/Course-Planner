package ca.cmpt213.as5courseplanner.controllers.datatransferobjects;

public class ApiCourseDTO {
    public long courseId;
    public String catalogNumber;
}
