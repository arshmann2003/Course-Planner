package ca.cmpt213.as5courseplanner.controllers.datatransferobjects;

public class ApiOfferingSectionDTO {
    public String type;
    public int enrollmentCap;
    public int enrollmentTotal;
}
