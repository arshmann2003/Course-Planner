package ca.cmpt213.as5courseplanner.controllers.datatransferobjects;

public class ApiDepartmentDTO {
    public long deptId;
    public String name;
}
