package ca.cmpt213.as5courseplanner.controllers.datatransferobjects;

public final class ApiWatcherCreateDTO {
    public long deptId;
    public long courseId;
}
